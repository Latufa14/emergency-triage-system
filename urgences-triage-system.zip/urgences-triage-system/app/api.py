import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import pandas as pd
import sqlite3
from datetime import datetime

# Initialisation de l’API

app = FastAPI(title="API Triage Médical")


# Chargement du modèle

try:
    model = joblib.load("pipeline_lightgbm.pkl")
    print("✅ Modèle chargé avec succès")
except Exception as e:
    print(f"❌ Erreur de chargement du modèle : {e}")
    model = None


# Schéma d’entrée (ce que le patient saisit)

class PatientInput(BaseModel):
    age: int
    sexe: str
    symptomes: str


# Fonction d’insertion en BDD

def insert_patient_and_consultation(age, sexe, symptomes, niveau_gravite, statut="En attente"):
    conn = sqlite3.connect("patients.db")
    cursor = conn.cursor()

    # 🔹 Insérer patient
    cursor.execute(
        """
        INSERT INTO Patient (age, sexe)
        VALUES (?, ?)
        """,
        (age, sexe),
    )
    id_patient = cursor.lastrowid  # Récupère l’ID du patient inséré

    # 🔹 Insérer consultation
    cursor.execute(
        """
        INSERT INTO Consultation (id_patient, description_symptomes, niveau_gravite, statut_triage, date_arrivee)
        VALUES (?, ?, ?, ?, ?)
        """,
        (id_patient, symptomes, niveau_gravite, statut, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )

    conn.commit()
    conn.close()
    print(f"💾 Patient {id_patient} enregistré avec gravité {niveau_gravite}")


# Endpoint de prédiction

@app.post("/predict")
def predict(input_data: PatientInput):
    if model is None:
        raise HTTPException(status_code=500, detail="Modèle non disponible")

    try:
        # 🔹 Préparer les données pour le modèle
        X_test = pd.DataFrame([{
            "age": input_data.age,
            "sexe": input_data.sexe,
            "symptomes_clean": input_data.symptomes
        }])

        # 🔹 Faire la prédiction
        prediction = int(model.predict(X_test)[0])
        probabilites = model.predict_proba(X_test)[0].tolist()

        # 🔹 Sauvegarder dans la base
        insert_patient_and_consultation(
            input_data.age,
            input_data.sexe,
            input_data.symptomes,
            prediction
        )

        return {
            "prediction": prediction,
            "probabilites": probabilites
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur interne API : {str(e)}")


# Lancement de l'API

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
