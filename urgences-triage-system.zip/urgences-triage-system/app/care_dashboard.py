import streamlit as st
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

DB_PATH = "patients.db"

# Connexion SQLite
def get_connection():
    return sqlite3.connect(DB_PATH, check_same_thread=False)

# Charger les données patients + consultations
def load_data():
    conn = get_connection()
    query = """
        SELECT c.id_consultation, p.id_patient, p.age, p.sexe, c.description_symptomes, 
               c.niveau_gravite, c.statut_triage, c.date_arrivee, c.date_prise_en_charge
        FROM Consultation c
        JOIN Patient p ON c.id_patient = p.id_patient
        ORDER BY c.date_arrivee DESC
    """
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

# Mettre à jour le statut d’un patient
def update_status(id_consultation, new_status):
    conn = get_connection()
    cursor = conn.cursor()
    if new_status == "Pris en charge":
        cursor.execute(
            "UPDATE Consultation SET statut_triage=?, date_prise_en_charge=? WHERE id_consultation=?",
            (new_status, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), id_consultation),
        )
    else:
        cursor.execute(
            "UPDATE Consultation SET statut_triage=? WHERE id_consultation=?",
            (new_status, id_consultation),
        )
    conn.commit()
    conn.close()


# Interface Streamlit

st.set_page_config(page_title="Interface Soignant - Urgences", layout="wide")
st.title(" Interface Soignant - Urgences")

df = load_data()

if df.empty:
    st.warning("⚠️ Aucun patient enregistré pour le moment.")
else:
  
    # KPIs en haut de page
   
    col1, col2, col3, col4 = st.columns(4)

    total_patients = len(df)
    en_attente = len(df[df["statut_triage"] == "En attente"])
    pris_en_charge = len(df[df["statut_triage"] == "Pris en charge"])
    termines = len(df[df["statut_triage"] == "Terminé"])

    col1.metric("👥 Total patients", total_patients)
    col2.metric("⏳ En attente", en_attente)
    col3.metric("⚡ Pris en charge", pris_en_charge)
    col4.metric("✅ Terminés", termines)

   
    # Mise en page 2 colonnes
  
    left, right = st.columns([1, 3])

    # ---- Colonne gauche = Actions ----
    with left:
        st.subheader("⚡ Prendre en charge / Mettre à jour")

        id_list = df["id_consultation"].tolist()
        selected_id = st.selectbox("Sélectionner une consultation", id_list)

        new_status = st.selectbox(
            "Changer le statut",
            ["En attente", "Pris en charge", "Terminé", "Redirigé"],
        )

        if st.button("✅ Mettre à jour le statut"):
            update_status(selected_id, new_status)
            st.success(f"✅ Consultation {selected_id} mise à jour → {new_status}")

    # ---- Colonne droite = Tableau ----
    with right:
        st.subheader("📋 Liste des patients")

        def color_gravite(val):
            colors = {0: "background-color: #90EE90", 1: "background-color: #FFD700", 2: "background-color: #FF8C00", 3: "background-color: #FF6347"}
            return colors.get(val, "")

        st.dataframe(
            df.style.applymap(color_gravite, subset=["niveau_gravite"]),
            use_container_width=True,
        )

   
    # Graphiques en bas
   
    st.subheader("📊 Statistiques")

    col_g1, col_g2, col_g3 = st.columns(3)

    # Répartition par gravité
    with col_g1:
        gravite_counts = df["niveau_gravite"].value_counts().sort_index()
        fig1, ax1 = plt.subplots()
        gravite_counts.plot(kind="bar", color=["green", "yellow", "orange", "red"], ax=ax1)
        ax1.set_title("Répartition par gravité")
        st.pyplot(fig1)

    # Répartition par statut
    with col_g2:
        statut_counts = df["statut_triage"].value_counts()
        fig2, ax2 = plt.subplots()
        statut_counts.plot(kind="pie", autopct="%1.1f%%", startangle=90, ax=ax2)
        ax2.set_ylabel("")
        ax2.set_title("Répartition par statut")
        st.pyplot(fig2)

    # Répartition par sexe
    with col_g3:
        sexe_counts = df["sexe"].value_counts()
        fig3, ax3 = plt.subplots()
        sexe_counts.plot(kind="bar", color=["#1f77b4", "#ff69b4"], ax=ax3)
        ax3.set_title("Répartition H/F")
        st.pyplot(fig3)
