import streamlit as st
import requests


# CONFIGURATION DE LA PAGE

st.set_page_config(page_title="Interface Patient - Triage Médical", page_icon="🧑‍⚕️", layout="centered")

st.title(" Interface Patient - Triage Médical")


# FORMULAIRE PATIENT

with st.form("formulaire_patient"):
    age = st.number_input("Âge", min_value=0, max_value=120, value=30)
    sexe = st.selectbox("Sexe", ["H", "F"])
    symptomes = st.text_area("Décrivez vos symptômes")

    submitted = st.form_submit_button("Soumettre")


# ENVOI À L’API

if submitted:
    if symptomes.strip() == "":
        st.error("❌ Veuillez entrer vos symptômes.")
    else:
        try:
            url = "http://127.0.0.1:8000/predict"

            data = {
                "age": age,
                "sexe": sexe,
                "symptomes": symptomes
            }

            response = requests.post(url, json=data)

            if response.status_code == 200:
                st.success("✅ Votre demande a bien été enregistrée. Merci, un soignant va vous prendre en charge rapidement.")
            else:
                st.error("⚠️ Une erreur est survenue, veuillez réessayer.")

        except Exception as e:
            st.error(f"🚨 Impossible de contacter l’API : {e}")
