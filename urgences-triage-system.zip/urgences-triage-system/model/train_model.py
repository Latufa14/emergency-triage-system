# train_model.py
import random
import re
import pandas as pd
import spacy
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, f1_score, balanced_accuracy_score, roc_auc_score, classification_report
from lightgbm import LGBMClassifier


# 1. Nettoyage basique

def nettoyer_texte(text):
    text = text.lower()
    text = re.sub(r"[éèêë]", "e", text)
    text = re.sub(r"[àâä]", "a", text)
    text = re.sub(r"[îï]", "i", text)
    text = re.sub(r"[ôö]", "o", text)
    text = re.sub(r"[ùûü]", "u", text)
    text = re.sub(r"[^a-zA-Z0-9, ]", " ", text)
    return text


# 2. Listes de symptômes

critiques = ["douleur thoracique","perte de connaissance","hemorragie","detresse respiratoire",
    "essoufflement","convulsions","traumatisme cranien","brulure cutanee",
    "reaction anaphylactique","syncope","cyanose","fracture"]

moderes = ["fievre","toux","vomissements","vertiges","maux de tete","diarrhee",
    "douleurs abdominales","brulures d estomac","sifflements respiratoires",
    "crise d asthme","nez bouche","fatigue intense","palpitations",
    "vision floue","tension elevee","tension basse","deshydratation"]

legers = ["rhume","courbatures","eternuements","fatigue","eruption cutanee",
    "urticaire","allergie","perte de l odorat","perte du gout",
    "mal de gorge","perte d appetit"]

symptomes_possibles = critiques + moderes + legers


# 3. Label heuristique

def label_heuristique(text, age):
    t = nettoyer_texte(text)
    if any(k in t for k in critiques):
        return 2
    if any(k in t for k in moderes):
        return 2 if age > 70 else 1
    if any(k in t for k in legers):
        return 1 if age > 65 else 0
    return 1


# 4. Génération dataset simulé

N = 10000
data = []
for _ in range(N):
    age = random.randint(1, 95)
    sexe = random.choice(["H", "F"])
    symptomes = ", ".join(random.sample(symptomes_possibles, k=random.randint(1, 4)))
    gravite = label_heuristique(symptomes, age)
    data.append([age, sexe, symptomes, gravite])

df = pd.DataFrame(data, columns=["age", "sexe", "symptomes", "niveau_gravite"])


# 5. Nettoyage NLP (spaCy)

nlp = spacy.load("fr_core_news_sm")

def nettoyer_texte_spacy(text):
    doc = nlp(str(text).lower())
    tokens = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct and not token.like_num]
    return " ".join(tokens)

df["symptomes_clean"] = df["symptomes"].apply(nettoyer_texte_spacy)


# 6. Split

X = df[["age", "sexe", "symptomes_clean"]]
y = df["niveau_gravite"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)


# 7. Pipeline complet

preprocessor = ColumnTransformer(transformers=[
    ("text", TfidfVectorizer(ngram_range=(1,2), min_df=2), "symptomes_clean"),
    ("cat", OneHotEncoder(handle_unknown="ignore"), ["sexe"]),
    ("num", "passthrough", ["age"])
])

pipeline_final = Pipeline([
    ("preprocess", preprocessor),
    ("clf", LGBMClassifier(
        n_estimators=300,
        learning_rate=0.1,
        max_depth=-1,
        class_weight="balanced",
        random_state=42
    ))
])


# 8. Entraînement

pipeline_final.fit(X_train, y_train)


# 9. Évaluation rapide

y_pred = pipeline_final.predict(X_test)
print("✅ Accuracy:", accuracy_score(y_test, y_pred))
print("✅ Balanced Accuracy:", balanced_accuracy_score(y_test, y_pred))
print("✅ F1-macro:", f1_score(y_test, y_pred, average="macro"))
print("\n📊 Rapport de classification:\n", classification_report(y_test, y_pred))


# 10. Sauvegarde

joblib.dump(pipeline_final, "pipeline_lightgbm.pkl")
print("🎉 Pipeline sauvegardé sous pipeline_lightgbm.pkl")
