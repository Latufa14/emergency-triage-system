# Système d’aide au triage des patients aux urgences

## Présentation du projet

Ce projet a été réalisé dans le cadre de mon mémoire de Mastère en Data Science.

L’objectif est de développer un système permettant d’aider au triage des patients aux urgences en évaluant automatiquement leur niveau de gravité à partir des symptômes et informations saisies.

L’application permet également de suivre l’activité du service à travers un tableau de bord présentant différents indicateurs.

## Fonctionnalités

- Saisie des informations et symptômes du patient
- Évaluation automatique du niveau de gravité
- Aide à la priorisation de la prise en charge des patients
- Tableau de bord pour le suivi de l’activité des urgences
- Calcul et visualisation d’indicateurs clés

## Indicateurs suivis

Le tableau de bord permet de suivre plusieurs indicateurs, notamment :

- Nombre total de patients
- Nombre de patients en attente
- Nombre de patients pris en charge
- Répartition des patients par niveau de gravité
- Temps d’attente moyen
- Suivi du flux des patients

## Technologies utilisées

- Python
- Pandas
- NumPy
- Scikit-learn
- LightGBM
- FastAPI
- Streamlit
- SQLite
- Matplotlib


### Description des dossiers

- **app/** : API FastAPI et interfaces utilisateurs (patient et soignant)  
- **model/** : entraînement et sauvegarde du modèle de prédiction  
- **database/** : initialisation de la base de données SQLite  
- **etl/** : scripts de traitement et de mise à jour des statistiques

## Objectif du projet

Ce projet illustre comment l'analyse de données, la modélisation et la visualisation peuvent être utilisées pour améliorer la gestion du flux de patients dans un service d’urgences et soutenir la prise de décision.