# etl_update_stats.py
import sqlite3
import pandas as pd
from datetime import datetime

DB_PATH = "triage.db"

def etl_for_today():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    today = datetime.now().strftime("%Y-%m-%d")
    print("[DEBUG] Connexion à la base :", DB_PATH)
    print("[DEBUG] Date du jour :", today)

    # 🔹 Récupération des consultations du jour
    df = pd.read_sql_query(
        "SELECT * FROM Consultation WHERE date_arrivee LIKE ?",
        con,
        params=[f"{today}%"]
    )

    if df.empty:
        print("[DEBUG] Aucune consultation trouvée pour aujourd'hui.")
        con.close()
        return

    print("[DEBUG] Nombre de consultations récupérées :", len(df))

    # 🔹 Calculs des KPIs
    nb_consult = len(df)
    nb_graves = (df["niveau_gravite"] == 2).sum()
    nb_moderes = (df["niveau_gravite"] == 1).sum()
    nb_legers = (df["niveau_gravite"] == 0).sum()

    # Temps d’attente moyen (en minutes) entre arrivée et prise en charge
    if "date_prise_en_charge" in df.columns:
        df = df.dropna(subset=["date_prise_en_charge"])
        if not df.empty:
            df["date_arrivee"] = pd.to_datetime(df["date_arrivee"])
            df["date_prise_en_charge"] = pd.to_datetime(df["date_prise_en_charge"])
            df["attente_min"] = (df["date_prise_en_charge"] - df["date_arrivee"]).dt.total_seconds() / 60
            attente_moyenne = df["attente_min"].mean()
        else:
            attente_moyenne = None
    else:
        attente_moyenne = None

    # Exemple : saturation si plus de 100 patients dans la journée
    taux_saturation = nb_consult / 100

    print("[DEBUG] Insertion en cours dans Statistiques...")

    cur.execute(
        """
        INSERT INTO Statistiques(date_stats, nb_consultations, nb_graves, nb_moderes, nb_legers, attente_moyenne_min, taux_saturation)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (today, nb_consult, nb_graves, nb_moderes, nb_legers, attente_moyenne, taux_saturation)
    )

    con.commit()
    con.close()
    print("✅ Statistiques insérées avec succès.")

if __name__ == "__main__":
    etl_for_today()
