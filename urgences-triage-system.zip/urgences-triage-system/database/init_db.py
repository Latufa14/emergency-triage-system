import sqlite3

# Connexion à la base
conn = sqlite3.connect("patients.db")
cursor = conn.cursor()

# Création de la table Patient
cursor.execute("""
CREATE TABLE IF NOT EXISTS Patient (
    id_patient INTEGER PRIMARY KEY AUTOINCREMENT,
    age INTEGER,
    sexe TEXT
)
""")

# Création de la table Consultation
cursor.execute("""
CREATE TABLE IF NOT EXISTS Consultation (
    id_consultation INTEGER PRIMARY KEY AUTOINCREMENT,
    id_patient INTEGER,
    description_symptomes TEXT,
    niveau_gravite INTEGER,
    statut_triage TEXT,
    date_arrivee TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_prise_en_charge TIMESTAMP,
    FOREIGN KEY (id_patient) REFERENCES Patient (id_patient)
)
""")

conn.commit()
conn.close()
print("✅ Base de données initialisée avec succès.")
